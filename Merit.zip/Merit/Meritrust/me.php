<?php
$send="@yahoo.com"// your email
?>